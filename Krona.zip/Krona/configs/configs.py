from environs import Env


class MainConfig:
    bot_token: str

    def __init__(self, main_config_data_path: str) -> None:
        Environment = Env()
        Environment.read_env(main_config_data_path)
        self.bot_token = Environment.str("BOT_TOKEN")


class MainDatabaseConfig:
    main_database_user_host: str
    main_database_user_host_port: str
    main_database_user_name: str
    main_database_user_password: str

    def __init__(self, main_database_config_data_path: str) -> None:
        Environment = Env()
        Environment.read_env(main_database_config_data_path)
        self.main_database_user_host = Environment.str("MAIN_DATABASE_USER_HOST")
        self.main_database_user_host_port = Environment.str("MAIN_DATABASE_USER_HOST_PORT")
        self.main_database_user_name = Environment.str("MAIN_DATABASE_USER_NAME")
        self.main_database_user_password = Environment.str("MAIN_DATABASE_USER_PASSWORD")
