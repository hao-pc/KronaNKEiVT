import asyncio
from configs.configs import MainConfig
from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from sources.autodeleter_user_messages.autodeleter_user_messages import autodeleterUserMessages
from sources.handlers.auth_handlers import auth, getnumb, getFIO
from sources.states.states import RegStates

MainConfig: MainConfig = MainConfig("configs/configs_data/main_config_data")

Bot = Bot(
    token=MainConfig.bot_token,
    default=DefaultBotProperties(
        parse_mode="html"
    )
)
Dispatcher: Dispatcher = Dispatcher()

Dispatcher.message.register(auth, F.text == "/start")
Dispatcher.message.register(getFIO, RegStates.GET_FIO)
Dispatcher.message.register(getnumb, RegStates.GET_NUMBER)

Dispatcher.message.register(autodeleterUserMessages)


async def launchBot() -> None:
    try:
        await Dispatcher.start_polling(Bot)
    finally:
        await Bot.session.close()
    return None


async def main() -> None:
    await asyncio.gather(
        launchBot()
    )
    return None

if __name__ == "__main__":
    asyncio.run(main())
