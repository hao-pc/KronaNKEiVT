from aiogram.fsm.state import StatesGroup, State


class RegStates(StatesGroup):
    GET_FIO = State()
    GET_NUMBER = State()
