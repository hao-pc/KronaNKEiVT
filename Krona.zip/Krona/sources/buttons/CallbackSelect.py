from sources.databases.databases import MainDatabase
from sources.handlers.Calendar import *
import datetime
from aiogram.utils.keyboard import InlineKeyboardBuilder
from calendar import monthrange
from aiogram.types import CallbackQuery
from aiogram.filters.callback_data import CallbackData
from aiogram import Bot

async def get_EventsKeyboards(date): #builder списка всех доступных мероприятий
    eventbuilder = InlineKeyboardBuilder()
    db = await MainDatabase.initialization("configs/configs_data/main_database_config_data", "crona_db")
    data = await db.fetch("SELECT * FROM events")
    
    for i in range(len(cur_calendar)): #Цикл что создает кнопки для каждого мероприятия в отдельности
        eventbuilder.button(
            text=f"{
            cur_calendar.iloc[i].values[1].strftime('%d.%m.%Y %H:%M'), #Дата
            cur_calendar.iloc[i].values[2], #Названия мероприятия
            cur_calendar.iloc[i].values[0], #Организатор/создатель мероприятия
            cur_calendar.iloc[i].values[3], #Вид мероприятия
            cur_calendar.iloc[i].values[4], #Location
            cur_calendar.iloc[i].values[5], #Интерес/Теги
            cur_calendar.iloc[i].values[6]}", #Количество участников
            callback_data="random_value"
        )    
    
    eventbuilder.button(
        text="Выход",
        callback_data=MonthCallbackFactory(value="0")
    )
    
    eventbuilder.adjust(1)
    return eventbuilder.as_markup()

class MonthCallbackFactory(CallbackData, prefix="fabmonth"):
    value: str

async def callbacks_month_select_fab(
        callback: CallbackQuery,
        bot: Bot,
        callback_data: MonthCallbackFactory
):
    if callback_data.value == "0": #Callback на вызов выбора месяца
        await MessagesActions.editMessageText(
            bot = bot,
            chat_id = callback.message.chat.id,
            message_id = callback.message.message_id,
            reply_markup = Calendar.get_MonthKeyboard(),
            text = "Выберите месяц проведения: "
        )
    else:
        await MessagesActions.editMessageText( #CallBack для вызова всего списка мероприятий в выбранный день
            bot = bot,
            chat_id = callback.message.chat.id,
            message_id = callback.message.message_id,
            reply_markup = get_EventsKeyboards(int(callback_data.value)),
            text = "Список событий в этом месяце:"
        )