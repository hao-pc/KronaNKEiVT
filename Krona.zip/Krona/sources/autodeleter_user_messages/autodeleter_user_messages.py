from aiogram import Bot
from aiogram.types import Message
from sources.messages_actions.messages_actions import MessagesActions


async def autodeleterUserMessages(message: Message, bot: Bot) -> None:
    await MessagesActions.deleteMessage(
        bot=bot,
        chat_id=message.from_user.id,
        message_id=message.message_id
    )
    return None
