from sources.databases.databases import UsersAuthorizationsDatabase
from aiosqlite import Connection


class AuthorizationsChecks:
    @staticmethod
    async def userAuthorizationCheck(users_authorizations_database: str, user_id: str) -> list | None:
        user_account: list | None = None
        try:
            _UsersAuthorizationsDatabase: Connection | None = await UsersAuthorizationsDatabase.initialization(
                users_authorizations_database=users_authorizations_database
            )
            if _UsersAuthorizationsDatabase is not None:
                user_account = await _UsersAuthorizationsDatabase.execute_fetchall("""SELECT * FROM UsersAuthorizations WHERE user_id = ?""", [user_id])
                await _UsersAuthorizationsDatabase.close()
        except Exception:
            return user_account
        return user_account

    @staticmethod
    async def accountAuthorizationCheck(users_authorizations_database: str, account_id: str) -> list | None:
        account_authorization: list | None = None
        try:
            _UsersAuthorizationsDatabase: Connection | None = await UsersAuthorizationsDatabase.initialization(
                users_authorizations_database=users_authorizations_database
            )
            if _UsersAuthorizationsDatabase is not None:
                account_authorization = await _UsersAuthorizationsDatabase.execute_fetchall("""SELECT * FROM UsersAuthorizations WHERE account_id = ?""", [account_id])
                await _UsersAuthorizationsDatabase.close()
        except Exception:
            return account_authorization
        return account_authorization
