from aiogram import Bot
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton
from aiogram.fsm.context import FSMContext
from sources.databases.databases import MainDatabase
from sources.messages_actions.messages_actions import MessagesActions
from sources.states.states import RegStates


async def auth(message: Message, bot: Bot, state: FSMContext) -> None:
    db = await MainDatabase.initialization("configs/configs_data/main_database_config_data", "crona_db")
    user = await db.fetch("SELECT * FROM users WHERE user_id = $1", message.from_user.id)
    if user:
        db = await MainDatabase.initialization("configs/configs_data/main_database_config_data", "crona_db")
        role = await db.fetch(
            'SELECT role FROM users WHERE user_id = $1', message.chat.id
        )
        await db.close()
        keyboard = [
            KeyboardButton(
                text="Календарь"
            ),
            KeyboardButton(
                text="Мои записи"
            ),
            KeyboardButton(
                text="Интересы"
            ),
        ]
        if int(role[0].get("role")) == 3:
            keyboard.append(
                KeyboardButton(
                    text="Модерация"
                )
            )
        keyboard_buttons = ReplyKeyboardMarkup(keyboard=[keyboard],
                                               row_width=1,
                                               resize_keyboard=True
                                               )
        await MessagesActions.sendMessage(
            bot=bot,
            chat_id=message.from_user.id,
            text="Добро пожаловать, вы в главном меню!",
            reply_markup=keyboard_buttons
        )
        await MessagesActions.deleteMessage(
            bot=bot,
            chat_id=message.from_user.id,
            message_id=message.message_id
        )
    else:
        await MessagesActions.sendMessage(
            bot=bot,
            chat_id=message.from_user.id,
            text="Здравствуйте! Для регистрации напишите свои ФИО:"
        )
        await state.set_state(RegStates.GET_FIO)


async def getFIO(message: Message, bot: Bot, state: FSMContext) -> None:
    try:
        name_split: list = message.text.split()
        name_list_counter: int = 0
        for _ in name_split:
            name_split[name_list_counter] = f"{_[0].upper()}{_[1:].lower()}"
            if "-" in name_split[name_list_counter]:
                name_part_split: list[str] = name_split[name_list_counter].split("-")
                name_part_list_counter: int = 0
                for __ in name_part_split:
                    name_part_split[name_part_list_counter] = f"{__[0].upper()}{__[1:].lower()}"
                    name_part_list_counter += 1
                name_split[name_list_counter] = "-".join(name_part_split)
            name_list_counter += 1
        name: str = " ".join(name_split)
        await state.update_data(
            fio=name
        )
    except Exception:
        await MessagesActions.sendMessage(
            bot=bot,
            chat_id=message.from_user.id,
            text="Вы ввели не текст! Пожалуйста, попробуйте ещё раз..."
        )
        return
    phone = ReplyKeyboardMarkup(
        keyboard=[
            [
                KeyboardButton(
                    text="Отправить номер телефона",
                    request_contact=True
                )
            ]
        ]
    )
    qmessage = await MessagesActions.sendMessage(
        bot=bot,
        chat_id=message.from_user.id,
        text="Теперь отправьте ваш номер телефона:",
        reply_markup=phone
    )
    await state.update_data(
        mes_id=qmessage.message_id
    )
    await state.set_state(RegStates.GET_NUMBER)


async def getnumb(message: Message, bot: Bot, state: FSMContext) -> None:
    try:
        try:
            user_phone_number = message.contact.phone_number
        except Exception:
            user_phone_number = message.text
        user_phone_number = user_phone_number.replace(" ", "")
        user_phone_number = user_phone_number.replace("-", "")
        user_phone_number = user_phone_number.replace("(", "")
        user_phone_number = user_phone_number.replace(")", "")
        if user_phone_number[0] != "+" and user_phone_number[0] != "7":
            user_phone_number = f"+{int(user_phone_number[0]) - 1}{user_phone_number[1:]}"
        elif user_phone_number[0] == "7":
            user_phone_number = f"+{user_phone_number}"
    except Exception:
        await MessagesActions.deleteMessage(
            bot=bot,
            chat_id=message.from_user.id,
            message_id=message.message_id
        )
        return
    state_data = await state.get_data()
    await MessagesActions.deleteMessage(
        bot=bot,
        chat_id=message.from_user.id,
        message_id=state_data.get("mes_id")
    )
    tags = "{\"обучение\": \"False\", \"нетворкинг\": \"False\", \"семейные мероприятия\": \"False\", \"путешествия\": \"False\", \"профильные встречи по отраслям\": \"False\"}"
    db = await MainDatabase.initialization("configs/configs_data/main_database_config_data", "crona_db")
    await db.execute("INSERT INTO users VALUES($1, $2, $3, $4, $5, $6, $7)", message.from_user.id, str(message.from_user.username), state_data.get("fio"), str(user_phone_number), str(tags), 0, 0)
    await db.close()
    await MessagesActions.sendMessage(
        bot=bot,
        chat_id=message.from_user.id,
        text="Вы успешно зарегистрированы!"
    )