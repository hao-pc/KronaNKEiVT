import asyncio
from aiogram.utils.keyboard import InlineKeyboardBuilder
from sources.messages_actions.messages_actions import MessagesActions
from aiogram.types import Message
from aiogram import Bot

def get_MonthKeyboard(): #Функция создание кнопок для выбора месяца
    builder = InlineKeyboardBuilder()
    builder.button(
        text="Январь", callback_data=MonthCallbackFactory(value="1")
    )
    builder.button(
        text="Февраль", callback_data=MonthCallbackFactory(value="2")
    )
    builder.button(
        text="Март", callback_data=MonthCallbackFactory(value="3")
    )
    builder.button(
        text="Апрель", callback_data=MonthCallbackFactory(value="4")
    )
    builder.button(
        text="Май", callback_data=MonthCallbackFactory(value="5")
    )
    builder.button(
        text="Июнь", callback_data=MonthCallbackFactory(value="6")
    )
    builder.button(
        text="Июль", callback_data=MonthCallbackFactory(value="7")
    )
    builder.button(
        text="Август", callback_data=MonthCallbackFactory(value="8")
    )
    builder.button(
        text="Сентябрь", callback_data=MonthCallbackFactory(value="9")
    )
    builder.button(
        text="Октябрь", callback_data=MonthCallbackFactory(value="10")
    )
    builder.button(
        text="Ноябрь", callback_data=MonthCallbackFactory(value="11")
    )
    builder.button(
        text="Декабрь", callback_data=MonthCallbackFactory(value="12")
    )
    builder.adjust(1)
    return builder.as_markup()

async def command_start_calendar(message: Message, bot: Bot) -> None: #Вызов меню с выбором месяца
    await MessagesActions.sendMessage(
        bot = bot,
        chat_id = message.chat.id,
        text = "Выберите месяц проведения: ",
        reply_markup = get_MonthKeyboard()
    )