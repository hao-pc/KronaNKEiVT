import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.filters.callback_data import CallbackData
from aiogram.types import CallbackQuery, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder
from environs import Env

env = Env()
env.read_env()

API_TOKEN = env.str("TELEGRAM_API_TOKEN")
bot = Bot(token=API_TOKEN)
dp = Dispatcher()

# Определяем кнопки клавиатуры
start_keyboard = ReplyKeyboardMarkup(
    keyboard=[[KeyboardButton(text="Интересы")]],
    resize_keyboard=True
)

# Доступные опции для тем и городов
themes = ["Обучение", "Нетворкинг", "Семейные мероприятия", "Путешествия", "Профильные встречи"]
cities = ["Новосибирск", "Москва", "Санкт-Петербург", "Дубай", "Китай"]

# Хранение данных пользователей
user_data = {}


# Определение фабрик для callback data
class ThemeCallbackFactory(CallbackData, prefix="theme"):
    value: str


class CityCallbackFactory(CallbackData, prefix="city"):
    value: str


class InterestsCallbackFactory(CallbackData, prefix="interests"):
    value: str

async def handleBack(callback: CallbackQuery):
    await bot.answer_callback_query(callback.id, "Вы нажали 'Назад'. Пока что ничего не происходит.")



def createMarkup(options, selected_items, callback_prefix, show_back_button=False):
    keyboard = InlineKeyboardBuilder()
    for option in options:
        if option in selected_items:
            text = f"✅ {option}"
        else:
            text = option

        if callback_prefix == ThemeCallbackFactory:
            callback_data = ThemeCallbackFactory(value=option).pack()
        elif callback_prefix == CityCallbackFactory:
            callback_data = CityCallbackFactory(value=option).pack()
        else:
            callback_data = InterestsCallbackFactory(value=option).pack()

        keyboard.button(text=text, callback_data=callback_data)

    # Если требуется кнопка "Назад"
    if show_back_button:
        keyboard.button(text="Назад", callback_data="back")
    else:
        keyboard.button(text="Далее", callback_data="next")

    keyboard.adjust(1)
    return keyboard.as_markup()



# Отправка сообщения
async def sendMessage(
        bot: Bot,
        chat_id: int,
        text: str,
        reply_markup: InlineKeyboardMarkup | ReplyKeyboardMarkup = None
):
    return await bot.send_message(chat_id=chat_id, text=text, reply_markup=reply_markup)


# Обработчики команд и callback query

async def startCommand(message: types.Message):
    await sendMessage(bot=bot, chat_id=message.chat.id,
                      text="Добро пожаловать! Нажмите 'Интересы', чтобы выбрать свои предпочтения.",
                      reply_markup=start_keyboard)


async def showInterests(message: types.Message):
    await sendMessage(
        bot=bot,
        chat_id=message.chat.id,
        text="Выберите интересы:",
        reply_markup=createMarkup(["Темы", "Город"], [], InterestsCallbackFactory, show_back_button=True)
    )



# Обработчик выбора тем
async def chooseThemes(callback: CallbackQuery):
    user_id = callback.from_user.id
    selected_themes = user_data.get(user_id, {}).get("themes", [])
    await bot.send_message(callback.from_user.id, "Выберите темы:", reply_markup=createMarkup(themes, selected_themes, ThemeCallbackFactory))


# Обработчик выбора городов
async def chooseCities(callback: CallbackQuery):
    user_id = callback.from_user.id
    selected_cities = user_data.get(user_id, {}).get("cities", [])
    await bot.send_message(callback.from_user.id, "Выберите города:", reply_markup=createMarkup(cities, selected_cities, CityCallbackFactory))


async def callbacksInterestsSelect(callback: CallbackQuery, callback_data: InterestsCallbackFactory):
    if callback_data.value == "Темы":
        await chooseThemes(callback)
    elif callback_data.value == "Город":
        await chooseCities(callback)


async def callbackThemeSelect(callback: CallbackQuery, callback_data: ThemeCallbackFactory):
    user_id = callback.from_user.id
    user_data.setdefault(user_id, {"themes": [], "cities": []})

    if callback_data.value in user_data[user_id]["themes"]:
        user_data[user_id]["themes"].remove(callback_data.value)
        await bot.answer_callback_query(callback.id, f"Тема '{callback_data.value}' снята.")
    else:
        user_data[user_id]["themes"].append(callback_data.value)
        await bot.answer_callback_query(callback.id, f"Тема '{callback_data.value}' выбрана.")

    await bot.edit_message_text(
        "Выберите темы:",
        chat_id=callback.from_user.id,
        message_id=callback.message.message_id,
        reply_markup=createMarkup(themes, user_data[user_id]["themes"], ThemeCallbackFactory)
    )


async def callbackCitySelect(callback: CallbackQuery, callback_data: CityCallbackFactory):
    user_id = callback.from_user.id
    user_data.setdefault(user_id, {"themes": [], "cities": []})

    if callback_data.value in user_data[user_id]["cities"]:
        user_data[user_id]["cities"].remove(callback_data.value)
        await bot.answer_callback_query(callback.id, f"Город '{callback_data.value}' снят.")
    else:
        user_data[user_id]["cities"].append(callback_data.value)
        await bot.answer_callback_query(callback.id, f"Город '{callback_data.value}' выбран.")

    await bot.edit_message_text(
        "Выберите города:",
        chat_id=callback.from_user.id,
        message_id=callback.message.message_id,
        reply_markup=createMarkup(cities, user_data[user_id]["cities"], CityCallbackFactory)
    )


async def finalizeChoice(callback: CallbackQuery):
    user_id = callback.from_user.id
    selected_themes = user_data.get(user_id, {}).get("themes", [])
    selected_cities = user_data.get(user_id, {}).get("cities", [])

    response = "Ваши выбранные темы:\n"
    response += f"{', '.join(selected_themes) if selected_themes else 'Темы не выбраны'}"

    response += "\n\nВаши выбранные города:\n"
    response += f"{', '.join(selected_cities) if selected_cities else 'Города не выбраны'}"

    await sendMessage(bot=bot, chat_id=callback.from_user.id, text=response)
    await bot.send_message(
        callback.from_user.id,
        "Выберите интересы:",
        reply_markup=createMarkup(["Темы", "Город"], [], InterestsCallbackFactory, show_back_button=True)
    )



# Регистрация обработчиков
async def launchBot():
    dp.message.register(startCommand, Command(commands=["start"]))
    dp.message.register(showInterests, lambda message: message.text == "Интересы")
    dp.callback_query.register(handleBack, lambda callback: callback.data == "back")
    dp.callback_query.register(callbacksInterestsSelect, InterestsCallbackFactory.filter())
    dp.callback_query.register(callbackThemeSelect, ThemeCallbackFactory.filter())
    dp.callback_query.register(callbackCitySelect, CityCallbackFactory.filter())
    dp.callback_query.register(finalizeChoice, lambda callback: callback.data == "next")

    await dp.start_polling(bot)


async def main():
    await launchBot()


if __name__ == "__main__":
    asyncio.run(main())
