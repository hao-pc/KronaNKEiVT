import pandas as pd
import pandasql
from MessagesActions import *
from datetime import datetime

async def schedule(bot) -> None:
    login_df = pd.DataFrame([["1094827260", "zColdBoy", "+79963824504"]], columns=["user_id", "username", "phone"])
    merop = pd.DataFrame([["1", "Какое-то мероприятие 1", "где-то", "1726905600"], ["2", "туса", "тоже где-то", "1726905600"]], columns=["event_id", "event_name", "event_location", "event_time"])
    subscribe_users = pd.DataFrame([["1094827260", "1, 2"]], columns=["user_id", "events_id"])

    while True:
        curr_dt = datetime.now()
        #Ищем мероприятия из базы, где время мероприятия будет меньше нашего времени + 1 час.
        events = pandasql.sqldf(
            f"SELECT * FROM merop WHERE event_time < {int(round(curr_dt.timestamp()))+3600}",
            locals())
        for event_id in events["event_id"]:
            subs = pandasql.sqldf(f"SELECT user_id, events_id FROM subscribe_users", locals())
            for user_id in subs["user_id"]:
                if event_id in subs["events_id"][0]:
                    await MessagesActions.sendMessage(
                        bot=bot,
                        chat_id=user_id,
                        text=f"Скоро мероприятие под названием {pandasql.sqldf(f"SELECT event_name FROM merop WHERE event_id = '{event_id}'", locals())["event_name"][0]}",
                    )
        await asyncio.sleep(120)