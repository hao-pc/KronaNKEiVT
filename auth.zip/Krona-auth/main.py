import logging
from aiogram import Bot, Dispatcher
from aiogram import F

from states import *
from Handlers.auth_handler import authHandler
from Handlers.text_number_handler import textNumberHandler
from Handlers.menu_handler import menu
from Handlers.test_handler import *
from schedule_event_notifications import schedule

logging.basicConfig(level=logging.INFO)
bot = Bot(token="7971228144:AAHyAo-QAmRp_pgWXsbzLRRZ0f4Xt5xnnEI")
dispatcher = Dispatcher()

dispatcher.message.register(authHandler, F.text == "/auth")
dispatcher.message.register(testHandler, F.text == "/subscribe")
dispatcher.message.register(menu, F.text == "/menu")
dispatcher.message.register(textNumberHandler, NumberPhone.number_phone)


async def launchBot() -> None:
    await dispatcher.start_polling(bot)

async def main() -> None:
    await asyncio.gather(
        launchBot(),
    )

if __name__ == "__main__":
    asyncio.run(main())