from aiogram.fsm.state import StatesGroup, State
class NumberPhone(StatesGroup):
    number_phone = State()

class LoginState(StatesGroup):
    logged = State()