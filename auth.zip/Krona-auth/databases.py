import asyncpg
import aiosqlite
from aiosqlite import Connection
from configs.configs import MainDatabaseConfig
import asyncio
from typing import Any

class MainDatabase:
    @staticmethod
    async def initialization(
        main_database_config_data_path: str,
        main_database_name: str
    ) -> Any | None:
        _MainDatabase: Any | None = None
        attempts_count: int = 0
        while attempts_count < 5:
            try:
                _MainDatabaseConfig: MainDatabaseConfig = MainDatabaseConfig(main_database_config_data_path)
                _MainDatabase = await asyncpg.connect(
                    host=_MainDatabaseConfig.main_database_user_host,
                    port=_MainDatabaseConfig.main_database_user_host_port,
                    user=_MainDatabaseConfig.main_database_user_name,
                    password=_MainDatabaseConfig.main_database_user_password,
                    database=main_database_name
                )
                break
            except Exception:
                await asyncio.sleep(1)
                attempts_count += 1
        return _MainDatabase


class UsersAuthorizationsDatabase:
    @staticmethod
    async def initialization(
        users_authorizations_database: str
    ) -> Connection | None:
        _UsersAuthorizationsDatabase: Connection | None = None
        attempts_count: int = 0
        while attempts_count < 5:
            try:
                _UsersAuthorizationsDatabase = await aiosqlite.connect(
                    database=users_authorizations_database
                )
                break
            except Exception:
                await asyncio.sleep(1)
                attempts_count += 1
        return _UsersAuthorizationsDatabase
