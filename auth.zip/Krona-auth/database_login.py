import asyncpg

async def getUsernameFromNumber(number: str) -> str:
    conn = await asyncpg.connect(user='',
                                 password='',
                                 database='',
                                 host=''
                                 )
    result_database = await conn.fetch(
        'SELECT username FROM users WHERE phone = ?',
        number,
    )
    await conn.close()
    return result_database[0]