from aiogram import types
from MessagesActions import *
from aiogram.fsm.context import FSMContext
from states import NumberPhone
async def authHandler(
        message: types.Message,
        state: FSMContext) -> None:
    keyboard_buttons = ReplyKeyboardMarkup(
        keyboard=[
            [
                types.KeyboardButton(
                    text="Поделиться номером телефона",
                    request_contact=True
                )
            ]
        ], row_width=1, resize_keyboard=True, one_time_keyboard=True
    )
    await MessagesActions.sendMessage(
        bot = message.bot,
        chat_id = message.chat.id,
        text = "Нажмите кнопку для предоставления номера или введите его в формате +7XXXXXXXXXX",
        reply_markup = keyboard_buttons
    )
    await state.set_state(NumberPhone.number_phone)