from MessagesActions import *
from aiogram import types
from databases import MainDatabase


async def menu(message: types.Message) -> None:
    role = 0
    db = await MainDatabase.initialization(".env", "crona_db")
    role = await db.fetch(
        'SELECT role FROM users WHERE user_id = $1', message.chat.id
    )
    await db.close()
    keyboard =[
            types.KeyboardButton(
                text="Календарь"
            ),
            types.KeyboardButton(
                text="Мои записи"
            ),
            types.KeyboardButton(
                text="Интересы"
            ),
    ]
    if int(role[0][0]) == 3:
        keyboard.append(
            types.KeyboardButton(
            text="Модерация"
            )
        )
    keyboard_buttons = ReplyKeyboardMarkup(keyboard=[keyboard],
                                           row_width=1,
                                           resize_keyboard=True
    )
    await MessagesActions.sendMessage(
        bot = message.bot,
        chat_id = message.chat.id,
        text = "Вам открыта менюшечка",
        reply_markup=keyboard_buttons
    )