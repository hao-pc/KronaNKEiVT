from MessagesActions import *
from aiogram import types

users_id = []
bot_bot = ""

async def testHandler(message: types.Message) -> None:
    if not message.chat.id in users_id:
        users_id.append(message.chat.id)
        await MessagesActions.sendMessage(
            bot = message.bot,
            chat_id = message.chat.id,
            text = "Подписался",
        )