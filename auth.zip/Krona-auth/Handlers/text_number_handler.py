import re
from MessagesActions import *
from aiogram.fsm.context import FSMContext
from states import LoginState
from database_login import getUsernameFromNumber
from aiogram import types
import pandas as pd
import pandasql

async def textNumberHandler(message: types.Message, state: FSMContext) -> None:
    #Тестовый вход!
    await state.clear()
    login_df = pd.DataFrame([["zColdBoy", "+79963824504"]], columns=["username", "phone"])
    if message.contact is not None:
        username = pandasql.sqldf(
            f"SELECT username FROM login_df WHERE phone = '+{message.contact.phone_number}'",
            locals())
        if (message.from_user.username == username["username"][0]):
            await MessagesActions.sendMessage(
                bot = message.bot,
                chat_id = message.chat.id,
                text = "Вы успешно вошли в систему"
            )
            await state.set_state(LoginState.logged)
        else:
            await MessagesActions.sendMessage(
                bot = message.bot,
                chat_id = message.chat.id,
                text = "Ваш юзернейм не соответствует юзернейму из базы данных."
            )
    else:
        number_regular = re.search('^((\+7|7|8)+([0-9]){10})$', message.text)
        if number_regular:
            username = pandasql.sqldf(
                f"SELECT username FROM login_df WHERE phone = '{message.text}'",
                locals())
            if (message.from_user.username == username["username"][0]):
                await MessagesActions.sendMessage(
                    bot = message.bot,
                    chat_id = message.chat.id,
                    text = "Вы успешно вошли в систему"
                )
                await state.set_state(LoginState.logged)