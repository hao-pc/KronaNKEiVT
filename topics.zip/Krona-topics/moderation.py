from aiogram import Bot, Dispatcher, types, F
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery, ReplyKeyboardMarkup, KeyboardButton
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.storage.memory import MemoryStorage
import asyncio
import pandas as pd
from environs import Env

# Настройки бота через environs
env = Env()
env.read_env()
API_TOKEN = env.str("TELEGRAM_API_TOKEN")
bot = Bot(token=API_TOKEN)
dp = Dispatcher(storage=MemoryStorage())

# Пример данных для таблицы Users
users_data = {
    "UserID": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],  # Добавлено больше пользователей для примера пагинации
    "Username": ["admin", "user1", "user2", "user3", "user4", "user5", "user6", "user7", "user8", "user9", "user10"],
    "FSLuser": ["Admin FSL", "User One", "User Two", "User Three", "User Four", "User Five", "User Six", "User Seven", "User Eight", "User Nine", "User Ten"],
    "Phone": ["+123456789", "+987654321", "+1122334455", "+2233445566", "+3344556677", "+4455667788", "+5566778899", "+6677889900", "+7788990011", "+8899001122", "+9900112233"],
    "Tags": ['["admin"]', '["networking"]', '["family"]', '["music"]', '["sports"]', '["art"]', '["tech"]', '["science"]', '["health"]', '["finance"]', '["education"]'],
    "Roles": [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    "CircleTable": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
}

# Пример данных для таблицы Events
events_data = {
    "EventID": [101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111],
    "EventName": ["Networking Event", "Family Event", "Training Event", "Music Event", "Sports Event", "Art Exhibition", "Tech Conference", "Science Fair", "Health Workshop", "Finance Seminar", "Education Conference"],
    "EventCreatorID": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
    "EventLocation": ["Room 1", "Room 2", "Room 3", "Room 4", "Room 5", "Room 6", "Room 7", "Room 8", "Room 9", "Room 10", "Room 11"],
    "EventType": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11],
    "EventTags": ['["networking"]', '["family"]', '["training"]', '["music"]', '["sports"]', '["art"]', '["tech"]', '["science"]', '["health"]', '["finance"]', '["education"]'],
    "EventMembers": [50, 30, 40, 60, 70, 80, 90, 100, 110, 120, 130],
    "EventConfirm": [True, False, True, True, False, True, False, True, False, True, False]
}

# Создание DataFrame
users_df = pd.DataFrame(users_data)
events_df = pd.DataFrame(events_data)

# FSM для управления состояниями модерации
class ModerationState(StatesGroup):
    view_tables = State()
    # Состояния для редактирования пользователя
    choosing_user = State()
    choose_column_user = State()
    edit_user_value = State()
    # Состояния для редактирования события
    choosing_event = State()
    choose_column_event = State()
    edit_event_value = State()

# Добавляем ваш user_id как администратора для теста
ADMIN_USER_ID = 1045667360  # Ваш реальный user_id

# Функция проверки роли администратора
async def isAdmin(user_id: int) -> bool:
    if user_id == ADMIN_USER_ID:
        return True  # Вы будете считаться администратором
    user = users_df[users_df["UserID"] == user_id]
    return not user.empty and user.iloc[0]["Roles"] == 1

# Функция для создания стартовой клавиатуры с кнопкой "Модерация"
async def startCommand(message: types.Message):
    markup = ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="Модерация")]
    ], resize_keyboard=True)
    await message.answer("Привет! Используй кнопку ниже для модерации.", reply_markup=markup)

# Функция для создания кнопок модерации (Inline-клавиатура)
async def moderationMenu(message: types.Message):
    if await isAdmin(message.from_user.id):
        markup = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="Просмотр таблиц", callback_data="view_tables")],
            [InlineKeyboardButton(text="Редактировать пользователей", callback_data="edit_users")],
            [InlineKeyboardButton(text="Редактировать события", callback_data="edit_events")]
        ])
        await message.answer("Панель модерации:", reply_markup=markup)
    else:
        await message.answer("У вас нет прав для модерации.")

# Функция для обработки нажатия на действия в модерации
async def handleModeration(callback: CallbackQuery, state: FSMContext):
    if callback.data == "view_tables":
        await callback.message.answer(f"Таблица Users:\n{users_df}\n\nТаблица Events:\n{events_df}")
        await state.set_state(ModerationState.view_tables)
    elif callback.data == "edit_users":
        await showUserList(callback.message, state, page=0)
        await state.set_state(ModerationState.choosing_user)
    elif callback.data == "edit_events":
        await showEventList(callback.message, state, page=0)
        await state.set_state(ModerationState.choosing_event)

async def handleUserSelection(callback: CallbackQuery, state: FSMContext):
    data = callback.data
    if data.startswith("user_page_"):
        page = int(data.split("_")[-1])
        await showUserList(callback.message, state, page)
    elif data.startswith("select_user_"):
        user_id = int(data.split("_")[-1])
        user = users_df[users_df["UserID"] == user_id]
        await callback.message.answer(f"Selected user: {user['Username'].values[0]}")
        markup = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="Username", callback_data="edit_username")],
            [InlineKeyboardButton(text="FSLuser", callback_data="edit_fsluser")],
            [InlineKeyboardButton(text="Phone", callback_data="edit_phone")],
            [InlineKeyboardButton(text="Tags", callback_data="edit_tags")],
            [InlineKeyboardButton(text="Roles", callback_data="edit_roles")],
            [InlineKeyboardButton(text="CircleTable", callback_data="edit_circle_table")]
        ])
        await callback.message.answer("Выберите столбец для редактирования:", reply_markup=markup)
        await state.set_state(ModerationState.choose_column_user)
        await callback.answer()

async def handleEventSelection(callback: CallbackQuery, state: FSMContext):
    data = callback.data
    if data.startswith("event_page_"):
        page = int(data.split("_")[-1])
        await showEventList(callback.message, state, page)
    elif data.startswith("select_event_"):
        event_id = int(data.split("_")[-1])
        event = events_df[events_df["EventID"] == event_id]
        await callback.message.answer(f"Selected event: {event['EventName'].values[0]}")
        markup = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="EventName", callback_data="edit_event_name")],
            [InlineKeyboardButton(text="EventLocation", callback_data="edit_event_location")],
            [InlineKeyboardButton(text="EventType", callback_data="edit_event_type")],
            [InlineKeyboardButton(text="EventTags", callback_data="edit_event_tags")],
            [InlineKeyboardButton(text="EventMembers", callback_data="edit_event_members")],
            [InlineKeyboardButton(text="EventConfirm", callback_data="edit_event_confirm")]
        ])
        await callback.message.answer("Выберите столбец для редактирования:", reply_markup=markup)
        await state.set_state(ModerationState.choose_column_event)
        await callback.answer()

async def showUserList(message: types.Message, state: FSMContext, page: int = 0):
    users_per_page = 10
    start_idx = page * users_per_page
    end_idx = start_idx + users_per_page
    total_pages = (len(users_df) - 1) // users_per_page + 1
    user_buttons = []
    for _, row in users_df.iloc[start_idx:end_idx].iterrows():
        user_buttons.append([InlineKeyboardButton(text=f"{row['UserID']}: {row['Username']}", callback_data=f"select_user_{row['UserID']}")])
    navigation_buttons = []
    if page > 0:
        navigation_buttons.append(InlineKeyboardButton(text="⬅️ Предыдущая", callback_data=f"user_page_{page - 1}"))
    if page < total_pages - 1:
        navigation_buttons.append(InlineKeyboardButton(text="Следующая ➡️", callback_data=f"user_page_{page + 1}"))
    markup = InlineKeyboardMarkup(inline_keyboard=user_buttons + [navigation_buttons])
    await message.answer("Выберите пользователя:", reply_markup=markup)
    await state.update_data(user_list_page=page)

async def showEventList(message: types.Message, state: FSMContext, page: int = 0):
    events_per_page = 10
    start_idx = page * events_per_page
    end_idx = start_idx + events_per_page
    total_pages = (len(events_df) - 1) // events_per_page + 1
    event_buttons = []
    for _, row in events_df.iloc[start_idx:end_idx].iterrows():
        event_buttons.append([InlineKeyboardButton(text=f"{row['EventID']}: {row['EventName']}", callback_data=f"select_event_{row['EventID']}")])
    navigation_buttons = []
    if page > 0:
        navigation_buttons.append(InlineKeyboardButton(text="⬅️ Предыдущая", callback_data=f"event_page_{page - 1}"))
    if page < total_pages - 1:
        navigation_buttons.append(InlineKeyboardButton(text="Следующая ➡️", callback_data=f"event_page_{page + 1}"))
    markup = InlineKeyboardMarkup(inline_keyboard=event_buttons + [navigation_buttons])
    await message.answer("Выберите событие:", reply_markup=markup)
    await state.update_data(event_list_page=page)

# Обработка выбора столбца для редактирования пользователя
async def chooseColumnUser(callback: CallbackQuery, state: FSMContext):
    user_data = await state.get_data()
    user_id = user_data['user_id']
    column_mapping = {
        "edit_username": "Username",
        "edit_fsluser": "FSLuser",
        "edit_phone": "Phone",
        "edit_tags": "Tags",
        "edit_roles": "Roles",
        "edit_circle_table": "CircleTable"
    }
    column = column_mapping.get(callback.data)
    if column:
        await callback.message.answer(f"Введите новое значение для {column}:")
        await state.update_data(column=column)
        await state.set_state(ModerationState.edit_user_value)
    else:
        await callback.message.answer("Неверный выбор.")
    await callback.answer()

# Обработка выбора столбца для редактирования события
async def chooseColumnEvent(callback: CallbackQuery, state: FSMContext):
    event_data = await state.get_data()
    event_id = event_data['event_id']
    column_mapping = {
        "edit_event_name": "EventName",
        "edit_event_location": "EventLocation",
        "edit_event_type": "EventType",
        "edit_event_tags": "EventTags",
        "edit_event_members": "EventMembers",
        "edit_event_confirm": "EventConfirm"
    }
    column = column_mapping.get(callback.data)
    if column:
        await callback.message.answer(f"Введите новое значение для {column}:")
        await state.update_data(column=column)
        await state.set_state(ModerationState.edit_event_value)
    else:
        await callback.message.answer("Неверный выбор.")
    await callback.answer()

# Обновление значения в выбранном столбце пользователя
async def updateUserValue(message: types.Message, state: FSMContext):
    user_data = await state.get_data()
    user_id = user_data['user_id']
    column = user_data['column']
    new_value = message.text
    # Обновляем значение в DataFrame
    users_df.loc[users_df["UserID"] == user_id, column] = new_value
    await message.answer(f"{column} обновлено. Новые данные пользователя:\n{users_df[users_df['UserID'] == user_id]}")
    await state.clear()  # Сброс состояния после обновления

# Обновление значения в выбранном столбце события
async def updateEventValue(message: types.Message, state: FSMContext):
    event_data = await state.get_data()
    event_id = event_data['event_id']
    column = event_data['column']
    new_value = message.text
    # Обновляем значение в DataFrame
    events_df.loc[events_df["EventID"] == event_id, column] = new_value
    await message.answer(f"{column} обновлено. Новые данные события:\n{events_df[events_df['EventID'] == event_id]}")
    await state.clear()  # Сброс состояния после обновления

# Регистрация хендлеров через регистр
async def launchBot():
    dp.message.register(startCommand, Command(commands=["start"]))
    dp.message.register(moderationMenu, lambda message: message.text == "Модерация")
    dp.callback_query.register(handleModeration, lambda callback: callback.data in ["view_tables", "edit_users", "edit_events"])
    # Обработчики для выбора пользователя с пагинацией
    dp.callback_query.register(handleUserSelection, F.state == ModerationState.choosing_user)
    # Обработчики для выбора события с пагинацией
    dp.callback_query.register(handleEventSelection, F.state == ModerationState.choosing_event)
    # Обработчик выбора столбца для пользователя
    dp.callback_query.register(chooseColumnUser, F.state == ModerationState.choose_column_user)
    # Обработчик выбора столбца для события
    dp.callback_query.register(chooseColumnEvent, F.state == ModerationState.choose_column_event)
    # Обработчик ввода нового значения для пользователя
    dp.message.register(updateUserValue, F.state == ModerationState.edit_user_value)
    # Обработчик ввода нового значения для события
    dp.message.register(updateEventValue, F.state == ModerationState.edit_event_value)
    await dp.start_polling(bot)

async def main():
    await launchBot()

if __name__ == "__main__":
    asyncio.run(main())