async def addEventCountMembers(message: Message, state: FSMContext):
    user_data = await state.update_data() #Редакция списка и инсерт в ивенты + creatorId, CreatorName, confirm,eventid
    await state.set_state(addEvent.EventCountMembers)
    await MessagesActions.sendMessage(
        bot = bot,
        chat_id = message.chat.id,
        text = "Мероприятие отправлено на одобрение администрации "
    )