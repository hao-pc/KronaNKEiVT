async def addEventDate(message: Message, state: FSMContext):
    pattern = r"^[0-3][0-9][///.\ -][0-1][0-9][///.\ -][2][0][0-9][0-9]$" #dd/mm/yyyy, необходимо дополнительная проверка дня и месяца
    if match(pattern, message.text) and int(message.text[-4:]) >= datetime.date.today().year:
        await state.update_data(EventDate=message.text)
        await state.set_state(addEvent.EventTime)
        await MessagesActions.sendMessage(
            bot = bot,
            chat_id = message.chat.id,
            text = "Введите время проведения мероприятия: "
        )
    else:
        await MessagesActions.sendMessage(
            bot = bot,
            chat_id = message.chat.id,
            text = "Кажется вы ввели не правильную дату, попробуйте ещё раз\nДату необходимо ввести в формате DD/MM/YYYY (12.12.2024)"
        )
        await state.set_state(addEvent.EventDate)