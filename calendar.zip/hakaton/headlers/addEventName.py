async def addEventName(message: Message, state: FSMContext):
    await state.update_data(EventName=message.text)
    await state.set_state(addEvent.EventLocation)
    await MessagesActions.sendMessage(
        bot = bot,
        chat_id = message.chat.id,
        text = "Выберите место проведение мероприятия: ",
        reply_markup = getLocationKeyboard()
    )