async def addEventLocation(message: Message, state: FSMContext):
    await state.update_data(EventLocation=message.text)
    await state.update_data(MaxMembers=100000)
    await state.set_state(addEvent.EventDate)
    await MessagesActions.sendMessage(
        bot = bot,
        chat_id = message.chat.id,
        text = "Введите дату проведения мероприятия: "
    )