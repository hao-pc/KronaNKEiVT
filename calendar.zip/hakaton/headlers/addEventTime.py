async def addEventTime(message: Message, state: FSMContext):
    date = await state.update_data()
    userLoc = date['EventLocation']
    userDate = date["EventDate"] + message.text
    #eventsDS = SELECT event_id, event_datetime WHERE event_location == userLoc [[x y]] 0 >= y >=1
    #Вывести столбцы event_Id, event_datetime где локация из базы совпадает с локацией юзера
    pattern = r"^[0-2][0-9][: ,;.///\][0-5][0-9]"
    if match(pattern, message.text):
        UserDateTime = datetime.datetime.strptime(
            f'{userDate[0:2]}/{userDate[3:5]}/{userDate[6:10]}{userDate[-5:-3]}/{userDate[-2:]}', '%d/%m/%Y%H/%M'
            )
        #for i in eventsDS: if i >= UserDateTime + datetime.timedelta(hours=-3) and i <= UserDateTime + datetime.timedelta(hours=3): deny else: conf
        #Если в базе есть мероприятие +-3ч от заданного пользователем сообщить об этом
        await state.update_data(EventDateTime=UserDateTime)
        await state.set_state(addEvent.EventType)
        await MessagesActions.sendMessage(
            bot = bot,
            chat_id = message.chat.id,
            text = "Выберите вид встречи: ",
            reply_markup = getTypeKeyboard()
        )
    else:
        await state.set_state(addEvent.EventTime)
        await MessagesActions.sendMessage(
            bot = bot,
            chat_id = message.chat.id,
            text = "Введите время проведения мероприятия в формате HH:MM (12:30): "
        )