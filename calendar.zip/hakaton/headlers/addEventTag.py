async def addEventTag(message: Message, state: FSMContext):
    print(await state.update_data())
    await state.update_data(EventTag=message.text)
    await state.set_state(addEvent.EventCountMembers)
    await MessagesActions.sendMessage(
        bot = bot,
        chat_id = message.chat.id,
        text = "Введите количество участников: "
    )
