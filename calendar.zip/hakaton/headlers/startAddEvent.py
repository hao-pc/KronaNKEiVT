class addEvent(StatesGroup):
    EventName = State()
    EventDate = State()
    EventTime = State()
    EventType = State()
    EventLocation = State()
    EventTag = State()
    EventCountMembers = State()

"""
add func
"""

async def startAddEvent(message: Message, state: FSMContext):
    await state.set_state(addEvent.EventName)
    await MessagesActions.sendMessage(
        bot=bot,
        chat_id=message.chat.id,
        text="Введите название мероприятия: "
    )
