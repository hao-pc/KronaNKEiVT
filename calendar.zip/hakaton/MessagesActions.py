import asyncio
from aiogram import Bot
from aiogram.types import Message, InlineKeyboardMarkup, ReplyKeyboardMarkup
class MessagesActions:
    @staticmethod
    async def sendMessage(
            bot: Bot = None,
            chat_id: int = None,
            text: str = None,
            reply_markup: InlineKeyboardMarkup | ReplyKeyboardMarkup = None
    ) -> Message | None:
        message: Message | None = None
        attempts_count: int = 0
        while attempts_count < 5:
            try:
                if reply_markup is None:
                    message = await bot.send_message(
                        chat_id=chat_id,
                        text=text
                    )
                elif reply_markup is not None:
                    message = await bot.send_message(
                        chat_id=chat_id,
                        text=text,
                        reply_markup=reply_markup
                    )
                break
            except Exception:
                await asyncio.sleep(3)
                attempts_count += 1
        return message

    @staticmethod
    async def editMessageText(
            bot: Bot = None,
            chat_id: int = None,
            message_id: int = None,
            text: str = None,
            reply_markup: InlineKeyboardMarkup = None

    ) -> Message | bool | None:
        message: Message | bool | None = None
        attempts_count: int = 0
        while attempts_count < 5:
            try:
                if reply_markup is None:
                    message = await bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=message_id,
                        text=text
                    )
                elif reply_markup is not None:
                    message = await bot.edit_message_text(
                        chat_id=chat_id,
                        message_id=message_id,
                        text=text,
                        reply_markup=reply_markup
                    )
                break
            except Exception:
                await asyncio.sleep(3)
                attempts_count += 1
        return message

    @staticmethod
    async def editMessageReplyMarkup(
            bot: Bot = None,
            chat_id: int = None,
            message_id: int = None,
            reply_markup: InlineKeyboardMarkup = None
    ) -> Message | bool | None:
        message: Message | bool | None = None
        attempts_count: int = 0
        while attempts_count < 5:
            try:
                message = await bot.edit_message_reply_markup(
                    chat_id=chat_id,
                    message_id=message_id,
                    reply_markup=reply_markup
                )
                break
            except Exception:
                await asyncio.sleep(3)
                attempts_count += 1
        return message

    @staticmethod
    async def deleteMessage(
            bot: Bot = None,
            chat_id: int = None,
            message_id: int = None
    ) -> bool | None:
        message: bool | None = None
        attempts_count: int = 0
        while attempts_count < 5:
            try:
                message = await bot.delete_message(
                    chat_id=chat_id,
                    message_id=message_id
                )
                break
            except Exception:
                await asyncio.sleep(3)
                attempts_count += 1
        return message