"""
CallBack
"""


def getTypeKeyboard():
    TypeBuilder = InlineKeyboardBuilder()
    TypeBuilder.button(
        text="Индивидуальная встреча",
        callback_data=TypeCallbackFactory(Type=1)
    )
    TypeBuilder.button(
        text="Встреча круглого стола",
        callback_data=TypeCallbackFactory(Type=2)
    )
    TypeBuilder.button(
        text="Отраслевой стол",
        callback_data=TypeCallbackFactory(Type=3)
    )
    TypeBuilder.button(
        text="Открытая встреча",
        callback_data=TypeCallbackFactory(Type=4)
    )
    TypeBuilder.adjust(1)
    return TypeBuilder.as_markup()


class TypeCallbackFactory(CallbackData, prefix="fabtype"):
    Type: int


async def callbackTypeSelect(
        callback: CallbackQuery,
        callback_data: TypeCallbackFactory,
        state: FSMContext
):
    await state.update_data(EventType=callback_data.Type)
    await MessagesActions.sendMessage(
        bot=bot,
        chat_id=callback.message.chat.id,
        text="Выберите тег мероприятия: "
    )
    await state.set_state(addEvent.EventTag)
    await MessagesActions.deleteMessage(
        bot=bot,
        chat_id=callback.message.chat.id,
        message_id=callback.message.message_id
    )


def getLocationKeyboard():
    LocationBuilder = InlineKeyboardBuilder()
    LocationBuilder.button(
        text="Новосибирск",
        callback_data=LocationCallbackFactory(adress="Новосибирск")
    )
    LocationBuilder.button(
        text="Москва",
        callback_data=LocationCallbackFactory(adress="Москва")
    )
    LocationBuilder.button(
        text="Санкт-Петербург",
        callback_data=LocationCallbackFactory(adress="Санкт-Петербург")
    )
    LocationBuilder.button(
        text="Дубай",
        callback_data=LocationCallbackFactory(adress="Дубай")
    )
    LocationBuilder.button(
        text="Китай",
        callback_data=LocationCallbackFactory(adress="Китай")
    )
    LocationBuilder.button(
        text="Онлайн",
        callback_data=LocationCallbackFactory(adress="Онлайн")
    )
    LocationBuilder.adjust(1)
    return LocationBuilder.as_markup()


def getLocationNSKKeyboard():
    LocationNSKBuilder = InlineKeyboardBuilder()
    LocationNSKBuilder.button(
        text="Переговорная 1",
        callback_data=LocationCallbackFactory(adress="Новосибирск, переговорная 1")
    )
    LocationNSKBuilder.button(
        text="Переговорная 2",
        callback_data=LocationCallbackFactory(adress="Новосибирск, переговорная 2")
    )
    LocationNSKBuilder.button(
        text="Переговорная 3",
        callback_data=LocationCallbackFactory(adress="Новосибирск, переговорная 3")
    )
    LocationNSKBuilder.button(
        text="Общий зал",
        callback_data=LocationCallbackFactory(adress="Новосибирск, общий зал")
    )
    LocationNSKBuilder.adjust(1)
    return LocationNSKBuilder.as_markup()


class LocationCallbackFactory(CallbackData, prefix="fabloc"):
    adress: str


async def callbacks_location_select_fab(
        callback: CallbackQuery,
        callback_data: LocationCallbackFactory,
        state: FSMContext
):
    if callback_data.adress == "Новосибирск":
        # if user have role
        await MessagesActions.editMessageText(
            bot=bot,
            chat_id=callback.message.chat.id,
            message_id=callback.message.message_id,
            text="Выберите необходимое действие: ",
            reply_markup=getLocationNSKKeyboard())


    elif callback_data.adress == "Онлайн":
        await MessagesActions.deleteMessage(
            bot=bot,
            chat_id=callback.message.chat.id,
            message_id=callback.message.message_id,
        )

        await MessagesActions.sendMessage(
            bot=bot,
            chat_id=callback.message.chat.id,
            text="Введите ссылку-приглашение: ",
        )
        await state.set_state(addEvent.EventLocation)

    elif callback_data.adress == "Новосибирск, переговорная 1":
        await state.update_data(EventLocation=callback_data.adress)
        await state.update_data(EventMaxMember=100000)
        await MessagesActions.deleteMessage(
            bot=bot,
            chat_id=callback.message.chat.id,
            message_id=callback.message.message_id,
        )
        await state.set_state(addEvent.EventDate)
        await MessagesActions.sendMessage(
            bot=bot,
            chat_id=callback.message.chat.id,
            text="Введите дату проведения мероприятия: "
        )

    elif callback_data.adress == "Новосибирск, переговорная 2":
        await state.update_data(EventLocation=callback_data.adress)
        await state.update_data(EventMaxMember=20)
        await MessagesActions.deleteMessage(
            bot=bot,
            chat_id=callback.message.chat.id,
            message_id=callback.message.message_id,
        )
        await state.set_state(addEvent.EventDate)
        await MessagesActions.sendMessage(
            bot=bot,
            chat_id=callback.message.chat.id,
            text="Введите дату проведения мероприятия: "
        )
    elif callback_data.adress == "Новосибирск, переговорная 3":
        await state.update_data(EventLocation=callback_data.adress)
        await state.set_state(addEvent.EventLocation)
        await state.update_data(EventMaxMember=20)
        await MessagesActions.deleteMessage(
            bot=bot,
            chat_id=callback.message.chat.id,
            message_id=callback.message.message_id,
        )
        await state.set_state(addEvent.EventDate)
        await MessagesActions.sendMessage(
            bot=bot,
            chat_id=callback.message.chat.id,
            text="Введите дату проведения мероприятия: "
        )

    elif callback_data.adress == "Новосибирск, общий зал":
        await state.update_data(EventLocation=callback_data.adress)
        await state.update_data(EventMaxMember=80)
        await MessagesActions.deleteMessage(
            bot=bot,
            chat_id=callback.message.chat.id,
            message_id=callback.message.message_id,
        )
        await state.set_state(addEvent.EventDate)
        await MessagesActions.sendMessage(
            bot=bot,
            chat_id=callback.message.chat.id,
            text="Введите дату проведения мероприятия: "
        )

    else:
        await state.update_data(EventLocation=callback_data.adress)
        await state.update_data(EventMaxMember=100000)
        await MessagesActions.deleteMessage(
            bot=bot,
            chat_id=callback.message.chat.id,
            message_id=callback.message.message_id,
        )
        await state.set_state(addEvent.EventDate)
        await MessagesActions.sendMessage(
            bot=bot,
            chat_id=callback.message.chat.id,
            text="Введите дату проведения мероприятия: "
        )