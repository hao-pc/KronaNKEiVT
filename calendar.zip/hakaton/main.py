import asyncio
from aiogram import Bot, Dispatcher
from headlers.Calendar import startCalendarMenu
from callback import CallbackSelect as cbs
from aiogram.client.default import DefaultBotProperties
from aiogram import F

bot = Bot(token="7285692535:AAHj-E4XiPzWsN_69Pq9fRnT1sbsV01NyfE", default=DefaultBotProperties(parse_mode="html"))
dp = Dispatcher()

dp.message.register(startCalendarMenu, F.text == "/start")
dp.callback_query.register(cbs.callbacks_month_select_fab, cbs.MonthCallbackFactory.filter())
dp.message.register(startAddEvent, F.text == "/start") # Заменить функцию"/start" на
# каллбек или иной конект с частью с просмотром
dp.message.register(addEventName, addEvent.EventName)
dp.message.register(addEventLocation, addEvent.EventLocation)
dp.message.register(addEventDate, addEvent.EventDate)
dp.message.register(addEventTime, addEvent.EventTime)
dp.message.register(addEventTag, addEvent.EventTag)
dp.message.register(addEventCountMembers, addEvent.EventCountMembers)
dp.callback_query.register(callbacks_location_select_fab, LocationCallbackFactory.filter())
dp.callback_query.register(callbackTypeSelect, TypeCallbackFactory.filter())



async def main() -> None:
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())